StuyAviators brand kit

Guidelines: https://stuyaviators.vercel.app/brand
Questions or permission requests: aviators-exec@stuy.edu
